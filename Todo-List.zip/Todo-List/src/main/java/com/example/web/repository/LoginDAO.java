package com.example.web.repository;

public class LoginDAO {

}
